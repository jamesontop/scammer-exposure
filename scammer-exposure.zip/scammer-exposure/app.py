from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import random
import string
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'bobo-secret-key-2026')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///scammers.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# ============================================================
# DATABASE MODELS
# ============================================================

class Scammer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    display_name = db.Column(db.String(200))
    description = db.Column(db.Text, nullable=False)
    channel = db.Column(db.String(200))
    channel_link = db.Column(db.String(300))
    profile_pic = db.Column(db.String(300), default='/static/default_avatar.png')
    reported_count = db.Column(db.Integer, default=0)
    is_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Scammer {self.username}>'

class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scammer_id = db.Column(db.Integer, db.ForeignKey('scammer.id'))
    reporter_name = db.Column(db.String(100))
    reason = db.Column(db.Text)
    evidence_link = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200))
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('⚠️ Admin access required!', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def generate_avatar(username):
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#FF8A5C']
    color = colors[hash(username) % len(colors)]
    letter = username[0].upper() if username else '?'
    return f'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="{color}"/><text x="50" y="55" font-size="40" text-anchor="middle" fill="white" font-family="Arial">{letter}</text></svg>'

# ============================================================
# ROUTES
# ============================================================

@app.route('/')
def index():
    scammers = Scammer.query.order_by(Scammer.created_at.desc()).all()
    total_scammers = len(scammers)
    total_reports = Report.query.count()
    return render_template('index.html', 
                         scammers=scammers, 
                         total_scammers=total_scammers,
                         total_reports=total_reports)

@app.route('/scammer/<username>')
def view_scammer(username):
    scammer = Scammer.query.filter_by(username=username).first_or_404()
    reports = Report.query.filter_by(scammer_id=scammer.id).all()
    return render_template('scammer_profile.html', scammer=scammer, reports=reports)

@app.route('/report', methods=['GET', 'POST'])
def report_scammer():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        description = request.form.get('description', '').strip()
        channel = request.form.get('channel', '').strip()
        channel_link = request.form.get('channel_link', '').strip()
        
        if not username or not description:
            flash('❌ Username and description are required!', 'danger')
            return redirect(url_for('report_scammer'))
        
        existing = Scammer.query.filter_by(username=username).first()
        if existing:
            flash(f'⚠️ {username} is already in the database!', 'warning')
            return redirect(url_for('index'))
        
        scammer = Scammer(
            username=username,
            display_name=username,
            description=description,
            channel=channel,
            channel_link=channel_link,
            profile_pic=generate_avatar(username),
            reported_count=1
        )
        db.session.add(scammer)
        db.session.commit()
        
        flash(f'✅ {username} has been added to the scammer list!', 'success')
        return redirect(url_for('index'))
    
    return render_template('report.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/stats')
def stats():
    total_scammers = Scammer.query.count()
    total_reports = Report.query.count()
    verified_scammers = Scammer.query.filter_by(is_verified=True).count()
    top_scammers = Scammer.query.order_by(Scammer.reported_count.desc()).limit(5).all()
    return render_template('stats.html', 
                         total_scammers=total_scammers,
                         total_reports=total_reports,
                         verified_scammers=verified_scammers,
                         top_scammers=top_scammers)

# ============================================================
# ADMIN ROUTES
# ============================================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('✅ Login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('❌ Invalid credentials!', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    scammers = Scammer.query.order_by(Scammer.created_at.desc()).all()
    reports = Report.query.order_by(Report.created_at.desc()).all()
    users = User.query.all()
    return render_template('admin.html', scammers=scammers, reports=reports, users=users)

@app.route('/admin/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_scammer(id):
    scammer = Scammer.query.get_or_404(id)
    if request.method == 'POST':
        scammer.username = request.form.get('username', scammer.username)
        scammer.display_name = request.form.get('display_name', scammer.display_name)
        scammer.description = request.form.get('description', scammer.description)
        scammer.channel = request.form.get('channel', scammer.channel)
        scammer.channel_link = request.form.get('channel_link', scammer.channel_link)
        scammer.is_verified = 'is_verified' in request.form
        db.session.commit()
        flash('✅ Scammer updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('edit_scammer.html', scammer=scammer)

@app.route('/admin/delete/<int:id>')
@login_required
@admin_required
def delete_scammer(id):
    scammer = Scammer.query.get_or_404(id)
    db.session.delete(scammer)
    db.session.commit()
    flash('🗑️ Scammer deleted successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/verify/<int:id>')
@login_required
@admin_required
def verify_scammer(id):
    scammer = Scammer.query.get_or_404(id)
    scammer.is_verified = not scammer.is_verified
    db.session.commit()
    status = 'verified' if scammer.is_verified else 'unverified'
    flash(f'✅ Scammer {status}!', 'success')
    return redirect(url_for('admin_dashboard'))

# ============================================================
# API ENDPOINTS
# ============================================================

@app.route('/api/scammers')
def api_scammers():
    scammers = Scammer.query.all()
    return jsonify([{
        'id': s.id,
        'username': s.username,
        'display_name': s.display_name,
        'description': s.description,
        'channel': s.channel,
        'channel_link': s.channel_link,
        'reported_count': s.reported_count,
        'is_verified': s.is_verified
    } for s in scammers])

# ============================================================
# CREATE DATABASE AND ADMIN USER
# ============================================================

def create_admin():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='ZiaaAdmin',
            password_hash=generate_password_hash('BluedditAdmienn143@#'),
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        print("✅ Admin user created! (username: admin, password: admin123)")
    
    initial_scammers = [
        {
            'username': 'its_Jeviee',
            'display_name': 'its_Jeviee',
            'description': '⚠️ SCAM ALERT: This user runs fake investment schemes on Telegram. Claims to double money but steals funds instead. Multiple victims reported.',
            'channel': 'Scammer Watch',
            'channel_link': 'https://t.me/scammerwatch'
        },
        {
            'username': 'SerenePo',
            'display_name': 'SerenePo',
            'description': '⚠️ SCAM ALERT: This user operates fake crypto giveaways. Asks for small deposits and never returns. Has been reported by 50+ victims.',
            'channel': 'Crypto Scam Alert',
            'channel_link': 'https://t.me/cryptoscamalert'
        }
    ]
    
    for data in initial_scammers:
        existing = Scammer.query.filter_by(username=data['username']).first()
        if not existing:
            scammer = Scammer(
                username=data['username'],
                display_name=data['display_name'],
                description=data['description'],
                channel=data['channel'],
                channel_link=data['channel_link'],
                profile_pic=generate_avatar(data['username']),
                reported_count=random.randint(10, 100)
            )
            db.session.add(scammer)
    db.session.commit()
    print("✅ Initial scammers added!")

# ============================================================
# MAIN
# ============================================================

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_admin()
    
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)